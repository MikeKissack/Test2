﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Interview;
using System.Collections.Generic;
using System.Linq;

namespace Interview.Test
{
    [TestClass]
    public class InterviewTests
    {
          [TestMethod]
        public void TestMethodAll1()
        {
            IStoreable TheSTore = new Storeable();
            IRepository<IStoreable> Repo2 = new TheRepository<IStoreable>();
            try
            {
                List<IStoreable> Ret = Repo2.All().ToList();
   
                Assert.IsTrue(Ret.Count == 0);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }
        }
        [TestMethod]
        public void TestMethodAll2()
        {
            IStoreable TheSTore = new Storeable();
            TheSTore.Id = 1;
            IRepository<IStoreable> Repo2 = new TheRepository<IStoreable>();

            Repo2.Save(TheSTore);
            try
            {
                //IEnumerable<IStoreable> Ret = Repo2.All();

                List<IStoreable> Ret = Repo2.All().ToList();

                Assert.IsTrue(Ret.Count == 1);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }
        }
        [TestMethod]
        public void TestMethodAll3()
        {
            IStoreable TheSTore = new Storeable
            { Id = 1 };
            IStoreable TheSTore2 = new Storeable
            { Id = 23 };

            IRepository<IStoreable> Repo2 = new TheRepository<IStoreable>();

            Repo2.Save(TheSTore);
            Repo2.Save(TheSTore2);
            try
            {
                List<IStoreable> Ret = Repo2.All().ToList();
                Assert.IsTrue(Ret.Count == 2);
                //check the order
                Assert.IsTrue((int)Ret[0].Id == 1);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }

        }

        [TestMethod]
        //string id
        public void TestMethodAll43()
        {
            IStoreable TheSTore = new Storeable
            { Id = "A" };
            IStoreable TheSTore2 = new Storeable
            { Id = "F" };

            IRepository<IStoreable> Repo2 = new TheRepository<IStoreable>();

            Repo2.Save(TheSTore);
            Repo2.Save(TheSTore2);
            try
            {
                List<IStoreable> Ret = Repo2.All().ToList();
                Assert.IsTrue(Ret.Count == 2);
                //check the order
                Assert.IsTrue((string)Ret[0].Id == "A");
                Assert.IsTrue((string)Ret[1].Id == "F");
            }
            catch (Exception e)
            {
                Assert.Fail();
            }

        }
        [TestMethod]
        public void TestMethodAll4()
        {
            IStoreable TheSTore = new Storeable
            { Id = 23 };
            IStoreable TheSTore2 = new Storeable
            { Id = 1 };

            IRepository<IStoreable> Repo2 = new TheRepository<IStoreable>();

            Repo2.Save(TheSTore);
            Repo2.Save(TheSTore2);
            try
            {
                List<IStoreable> Ret = Repo2.All().ToList();
                Assert.IsTrue(Ret.Count == 2);
                //check the order
                Assert.IsTrue((int)Ret[0].Id == 1);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public void TestAdd1()
        {
            IStoreable TheSTore = new Storeable
            { Id = 23 };
            IRepository<IStoreable> Repo2 = new TheRepository<IStoreable>();

            Repo2.Save(TheSTore);
            try
            {
                List<IStoreable> Ret = Repo2.All().ToList();
                Assert.IsTrue(Ret.Count == 1);
                //check the order
                Assert.IsTrue((int)Ret[0].Id == 23);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }

        }

        [TestMethod]
        public void TestAdd2()
        {
            IStoreable TheSTore = new Storeable
            { Id = "A" };
            IRepository<IStoreable> Repo2 = new TheRepository<IStoreable>();

            Repo2.Save(TheSTore);
            try
            {
                List<IStoreable> Ret = Repo2.All().ToList();
                Assert.IsTrue(Ret.Count == 1);
                //check the order
                Assert.IsTrue((string)Ret[0].Id == "A");
            }
            catch (Exception e)
            {
                Assert.Fail();
            }

        }

        [TestMethod]
        public void AddAgain()
        {
            IStoreable TheSTore = new Storeable
            { Id = 23 };
            IStoreable TheSTore2 = new Storeable
            { Id = 1 };

            IRepository<IStoreable> Repo2 = new TheRepository<IStoreable>();

            Repo2.Save(TheSTore);
            Repo2.Save(TheSTore2);
            try
            {
                List<IStoreable> Ret = Repo2.All().ToList();
                Assert.IsTrue(Ret.Count == 2);
                //check the order
                Assert.IsTrue((int)Ret[0].Id == 1);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }
            //Adsd agin
            Repo2.Save(TheSTore);
            try
            {
                List<IStoreable> Ret = Repo2.All().ToList();
                Assert.IsTrue(Ret.Count == 2);
                //check the order
                Assert.IsTrue((int)Ret[0].Id == 1);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public void TestMethodFindById1()
        {
            IStoreable TheSTore1 = new Storeable
            { Id = 23 };
            IStoreable TheSTore2 = new Storeable
            { Id = 1 };
            IStoreable TheSTore3 = new Storeable
            { Id = 7 };
            IRepository<IStoreable> Repo2 = new TheRepository<IStoreable>();

            Repo2.Save(TheSTore1);
            Repo2.Save(TheSTore2);
            Repo2.Save(TheSTore3);
            try
            {
                IStoreable Ret = Repo2.FindById(1);
                Assert.IsTrue((int)Ret.Id == 1);
            }
            catch
            {
                Assert.Fail();
            }

        }

        [TestMethod]
        //not exists
        public void TestMethodFindById2()
        {
            IStoreable TheSTore1 = new Storeable
            { Id = 23 };
            IStoreable TheSTore2 = new Storeable
            { Id = 1 };
            IStoreable TheSTore3 = new Storeable
            { Id = 7 };
            IRepository<IStoreable> Repo2 = new TheRepository<IStoreable>();

            Repo2.Save(TheSTore1);
            Repo2.Save(TheSTore2);
            Repo2.Save(TheSTore3);
            try
            {
                IStoreable Ret = Repo2.FindById(22);
            }
            catch (KeyNotFoundException)
            {
                Assert.IsTrue(1 == 1);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        //Not found
        public void TestMethodFindById3()
        {
            IStoreable TheSTore1 = new Storeable
            { Id = 23 };
            IStoreable TheSTore2 = new Storeable
            { Id = 1 };
            IStoreable TheSTore3 = new Storeable
            { Id = 7 };
            IRepository<IStoreable> Repo2 = new TheRepository<IStoreable>();

            Repo2.Save(TheSTore1);
            Repo2.Save(TheSTore2);
            Repo2.Save(TheSTore3);
            try
            {
                IStoreable Ret = Repo2.FindById(0);
            }
            catch (KeyNotFoundException)
            {
                Assert.IsTrue(1 == 1);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        //string and ints dont mix
        public void TestMethodFindById4()
        {
            IStoreable TheSTore1 = new Storeable
            { Id = 23 };
            IStoreable TheSTore2 = new Storeable
            { Id = "A" };
            IStoreable TheSTore3 = new Storeable
            { Id = 7 };
            IRepository<IStoreable> Repo2 = new TheRepository<IStoreable>();
            
            try
            {
                Repo2.Save(TheSTore1);
                Repo2.Save(TheSTore2);
                Repo2.Save(TheSTore3);
                ///IStoreable Ret = Repo2.FindById("A");
                ///Assert.IsTrue(Ret.Id.ToString() == "A");
            }
            catch (ArgumentException)
            {
                Assert.IsTrue(1 == 1);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public void TestMethodDelete1()
        {
            IStoreable TheSTore1 = new Storeable
            { Id = 23 };
            IStoreable TheSTore2 = new Storeable
            { Id = 1 };
            IStoreable TheSTore3 = new Storeable
            { Id = 7 };
            IRepository<IStoreable> Repo2 = new TheRepository<IStoreable>();

            Repo2.Save(TheSTore1);
            Repo2.Save(TheSTore2);
            Repo2.Save(TheSTore3);
            try
            {
                List<IStoreable> Ret = Repo2.All().ToList();
                Assert.IsTrue(Ret.Count == 3);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }
            try
            {
                int val = (int)TheSTore2.Id;
                Repo2.Delete(val);

                List<IStoreable> Ret2 = Repo2.All().ToList();
                Assert.IsTrue((int)Ret2[0].Id == 7);
                Assert.IsTrue((int)Ret2[1].Id == 23);
                Assert.IsTrue(Ret2.Count == 2);
            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public void TestMethodDelete2()
        {
            IStoreable TheSTore1 = new Storeable
            { Id = 23 };
            IStoreable TheSTore2 = new Storeable
            { Id = 1 };
            IStoreable TheSTore3 = new Storeable
            { Id = 7 };
            IRepository<IStoreable> Repo2 = new TheRepository<IStoreable>();

            Repo2.Save(TheSTore1);
            Repo2.Save(TheSTore2);
            Repo2.Save(TheSTore3);
            try
            {
                List<IStoreable> Ret = Repo2.All().ToList();
                Assert.IsTrue(Ret.Count == 3);
            }
            catch (KeyNotFoundException)
            {
                Assert.IsTrue(1 == 1);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }
            try
            {
                int val = 223;
                Repo2.Delete(val);
                List<IStoreable> Ret2 = Repo2.All().ToList();
                Assert.IsTrue(Ret2.Count == 3);
            }
            catch
            {
                Assert.Fail();
            }
        }

    }

    [TestClass]
    public class NewRepositoryTests
    {
        [TestMethod]
        //Test returns payload
        public void TestMethodNewObj1()
        {
            string text1 = "dddd";
            INewObject TheSTore1 = new NewObject();
            TheSTore1.Id = 1;
            TheSTore1.payload = text1;

            INewObject TheSTore2 = new NewObject();
            TheSTore2.Id = 2;
            TheSTore2.payload = "ccccc";

            INewRepository<INewObject> Repo2 = new NewRepository<INewObject>();

            Repo2.Save(TheSTore1);
            Repo2.Save(TheSTore2);

            try
            {
                INewObject Ret = Repo2.FindById(1);
                Assert.IsTrue(Ret.payload == text1);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        //Test Update of value
        public void TestMethodNewObj2()
        {
            string text1 = "dddd";
            string text2 = "ccccc";
            INewObject TheSTore1 = new NewObject();
            TheSTore1.Id = 1;
            TheSTore1.payload = text1;

            INewObject TheSTore2 = new NewObject();
            TheSTore2.Id = 1;
            TheSTore2.payload = text2;

            INewRepository<INewObject> Repo2 = new NewRepository<INewObject>();

            Repo2.Save(TheSTore1);
            Repo2.Save(TheSTore2);

            try
            {
                INewObject Ret = Repo2.FindById(1);
                Assert.IsTrue(Ret.payload == text2);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }
        }
    }
    
    [TestClass]
    public class StorableTest
    {
        [TestMethod]
        public void StoreTest1()
        {
            IStoreable TheSTore = new Storeable
            { Id = 23 };
            try
            {
                Assert.IsTrue(23 == (int)TheSTore.Id);
            }
            catch
            {
                Assert.Fail();
            }
        }
    }

    [TestClass]
    public class NewStorableTest1
    {
        [TestMethod]
        public void NewObjectTest1()
        {
            INewObject TheSTore = new NewObject
            { Id = 23, payload = "Test Text" };
            try
            {
                Assert.IsTrue(23 == (int)TheSTore.Id);
                Assert.IsTrue("Test Text" == TheSTore.payload);
            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public void NewObjectTest2()
        {
            INewObject TheSTore = new NewObject
            { Id = 23, payload = null };
            try
            {
                Assert.IsTrue(23 == (int)TheSTore.Id);
                Assert.IsTrue(null == TheSTore.payload);
            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public void NewObjectTest3()
        {
            INewObject TheSTore = new NewObject
            { Id = 23, payload = String.Empty };
            try
            {
                Assert.IsTrue(23 == (int)TheSTore.Id);
                Assert.IsTrue(String.Empty == TheSTore.payload);
            }
            catch
            {
                Assert.Fail();
            }
        }
    }
}






