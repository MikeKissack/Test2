﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;

namespace Interview
{
    public class NewRepository<T> : TheRepository<T>, INewRepository<T> where T : INewObject ,IStoreable
    {
        private SortedDictionary<IComparable, T> TheList = new SortedDictionary<IComparable, T>();
       
        public string GetText(IComparable id)
        {
            if (!TheList.TryGetValue(id, out T ReturnObject))
            {
                throw new KeyNotFoundException();
            }
            string oUTER = ReturnObject.payload;
            return oUTER;
        }

    }
}

