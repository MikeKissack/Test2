﻿using System;

namespace Interview
{
    public interface IStoreable
    {
        IComparable Id
        { get; set; }
    }
    
}