﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;

namespace Interview
{
    public class TheRepository<T> : IRepository<T> where T : IStoreable
    {
        private SortedDictionary<IComparable, T> TheList = new SortedDictionary<IComparable, T>();

        public IEnumerable<T> All()
        {
            return (IEnumerable < T >) TheList.Values;
        }

        public void Delete(IComparable id)
        {
            TheList.Remove(id);
        }

        public T FindById(IComparable id)
        {
            if(!TheList.TryGetValue(id, out T ReturnObject))
            {
                throw new KeyNotFoundException();
            }
            return ReturnObject;
        }

        public void Save(T item)
        {
            IComparable id = item.Id;
            try
            {
                
                TheList.Add(id, item);
            }
            catch (ArgumentException)
            {
                
                    TheList[id] = item;
            }
           
        }
    }
}
